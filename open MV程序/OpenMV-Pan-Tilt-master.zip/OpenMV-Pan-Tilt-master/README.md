# OpenMV-Pan-Tilt
OpenMV pan tilt robot

you need:

- OpenMV
- 3D printer part (pantilt/stl)
- anchor plate(pantilt/eagle)

![](https://raw.githubusercontent.com/SingTown/OpenMV-Pan-Tilt/master/pan-tilt/img/1.jpg)
